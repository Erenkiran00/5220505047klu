//
//  main.c
//  5220505043KLU
//
//  Created by mavlyuda almazova on 23.12.2023.
//

#include <stdio.h>
#include <stdlib.h>
int main(int argc, const char * argv[]) {
    
      typedef struct {
      int teklifveren_no;
      double teklif;
    } Teklif;
      // teklif verilen sayısımızı giriyoruz,
      int teklif_sayisi;
      printf("Teklif veren sayısını giriniz: ");
      scanf("%d", &teklif_sayisi);

      //burda verilen teklifleri saklamak için dizi oluşturuyoruz,
      Teklif teklifler[teklif_sayisi];

      // bütün teklifleri şimdi giriyoruz,
      for (int i = 0; i < teklif_sayisi; i++) {
        printf("Teklif veren %d, teklifinizi giriniz: ", i + 1);
        scanf("%lf", &teklifler[i].teklif);
      }

    // tekliflerin kazananını yazdırıyoruz,
      double en_yuksek_teklif = teklifler[0].teklif;
      int kazanan_teklifveren_no = teklifler[0].teklifveren_no;
      for (int i = 1; i < teklif_sayisi; i++) {
        if (teklifler[i].teklif > en_yuksek_teklif) {
          en_yuksek_teklif = teklifler[i].teklif;
          kazanan_teklifveren_no = teklifler[i].teklifveren_no;
        }
      }

    // en sonunda kazananı ve ödemeyi yazdırıyoruz,
      printf("Kazanan teklif veren: %d\n", kazanan_teklifveren_no);
      printf("Ödeme: %.2f TL\n", en_yuksek_teklif);
    
    
    // bütün teklifleri serbest bırakıyoruz,
    free("teklifler");

      return 0;
    }
